-- ============================================================
-- Script de création de la base de données : gestion_formations
-- TP6 - Architecture MVC - ISET'COM L2-GTIC
-- ============================================================

CREATE DATABASE IF NOT EXISTS gestion_formations
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE gestion_formations;

-- Table des formations
CREATE TABLE IF NOT EXISTS formations (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  titre       VARCHAR(150)   NOT NULL,
  description TEXT,
  prix        DECIMAL(8,2)   NOT NULL DEFAULT 0.00,
  duree       VARCHAR(50),
  niveau      VARCHAR(50)
) ENGINE=InnoDB;

-- Données de test
INSERT INTO formations (titre, description, prix, duree, niveau) VALUES
('Développement Web Full-Stack',
 'Maîtrisez HTML, CSS, JavaScript, PHP et MySQL pour créer des applications web complètes.',
 450.00, '3 mois', 'Débutant'),
('Intelligence Artificielle & Machine Learning',
 'Explorez les algorithmes de ML, les réseaux de neurones et Python scientifique.',
 750.00, '4 mois', 'Intermédiaire'),
('Cybersécurité & Ethical Hacking',
 'Apprenez à sécuriser les systèmes, détecter les vulnérabilités et prévenir les attaques.',
 600.00, '3 mois', 'Intermédiaire'),
('DevOps & Cloud Computing',
 'Docker, Kubernetes, CI/CD, AWS : maîtrisez l\'infrastructure moderne.',
 850.00, '5 mois', 'Avancé');

-- Table des inscriptions
CREATE TABLE IF NOT EXISTS inscriptions (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  nom               VARCHAR(100)  NOT NULL,
  prenom            VARCHAR(100)  NOT NULL,
  email             VARCHAR(150)  NOT NULL,
  formation_id      INT           NOT NULL,
  statut_paiement   ENUM('en_attente','paye','echec') NOT NULL DEFAULT 'en_attente',
  date_inscription  DATETIME      NOT NULL,
  FOREIGN KEY (formation_id) REFERENCES formations(id) ON DELETE CASCADE
) ENGINE=InnoDB;
