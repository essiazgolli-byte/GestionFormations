<?php
// ============================================================
// controllers/CoursController.php
// Rôle : préparer les données des cours (accès protégé par session)
// TP6 - Architecture MVC - ISET'COM L2-GTIC
// ============================================================

// La protection est déjà gérée dans index.php (redirection si pas de session)
// Ici on prépare les données à afficher dans la vue

$formation_titre = $_SESSION['formation_titre'] ?? 'Formation inconnue';
$etudiant_prenom = $_SESSION['etudiant_prenom'] ?? 'Étudiant';

// Contenu fictif des chapitres (dans un vrai projet, viendrait de la BD)
$chapitres = [
    [
        'numero' => 1,
        'titre'  => 'Introduction et mise en place de l\'environnement',
        'duree'  => '2h 30min',
        'icone'  => '📚',
    ],
    [
        'numero' => 2,
        'titre'  => 'Concepts fondamentaux et architecture',
        'duree'  => '3h 15min',
        'icone'  => '🏗️',
    ],
    [
        'numero' => 3,
        'titre'  => 'Pratique guidée — exercices corrigés',
        'duree'  => '4h 00min',
        'icone'  => '🛠️',
    ],
    [
        'numero' => 4,
        'titre'  => 'Projet final et évaluation',
        'duree'  => '2h 45min',
        'icone'  => '🎯',
    ],
];

require 'views/cours.php';
?>
