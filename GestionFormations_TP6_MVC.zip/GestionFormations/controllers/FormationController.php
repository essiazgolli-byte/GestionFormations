<?php
// ============================================================
// controllers/FormationController.php
// Rôle : récupérer la liste des formations et passer à la vue
// TP6 - Architecture MVC - ISET'COM L2-GTIC
// ============================================================

require_once 'models/Formation.php';

// Appel du modèle pour récupérer toutes les formations
$formations = Formation::getAll();

// Passer à la vue (les variables déclarées ici sont accessibles dans la vue)
require 'views/formations.php';
?>
