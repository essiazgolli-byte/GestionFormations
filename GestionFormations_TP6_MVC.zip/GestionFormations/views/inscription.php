<?php
// views/inscription.php — Formulaire d'inscription
$pageTitle = 'Inscription';
require 'views/partials/header.php';
?>

<section class="page-section form-page">
    <div class="page-header">
        <h1>Formulaire d'Inscription</h1>
        <p>Remplissez vos informations pour rejoindre la formation de votre choix.</p>
    </div>

    <!-- Afficher les erreurs de validation si elles existent -->
    <?php if (!empty($erreurs)): ?>
    <div class="alert alert-error">
        <strong>⚠ Erreurs détectées :</strong>
        <ul>
            <?php foreach ($erreurs as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Le formulaire poste vers le même contrôleur (POST) -->
    <form method="POST" action="index.php?page=inscription" class="form-card">
        <div class="form-row">
            <div class="form-group">
                <label for="nom">Nom <span class="required">*</span></label>
                <!-- value= permet de conserver la saisie après une erreur -->
                <input type="text" id="nom" name="nom"
                       value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>"
                       placeholder="Ex : Ayari" required>
            </div>
            <div class="form-group">
                <label for="prenom">Prénom <span class="required">*</span></label>
                <input type="text" id="prenom" name="prenom"
                       value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>"
                       placeholder="Ex : Asma" required>
            </div>
        </div>

        <div class="form-group">
            <label for="email">Adresse email <span class="required">*</span></label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   placeholder="exemple@email.com" required>
        </div>

        <div class="form-group">
            <label for="formation_id">Formation choisie <span class="required">*</span></label>
            <select id="formation_id" name="formation_id" required>
                <option value="">-- Choisir une formation --</option>
                <?php foreach ($formations as $f): ?>
                <option value="<?= $f['id'] ?>"
                    <?= ($formation_preselect == $f['id']
                        || (isset($_POST['formation_id']) && $_POST['formation_id'] == $f['id']))
                        ? 'selected' : '' ?>>
                    <?= htmlspecialchars($f['titre']) ?> — <?= number_format($f['prix'], 2, ',', ' ') ?> DT
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary btn-full">
            Continuer vers le paiement →
        </button>
    </form>
</section>

<?php require 'views/partials/footer.php'; ?>
