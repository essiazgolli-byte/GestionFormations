<?php
// views/home.php — Page d'accueil
$pageTitle = 'Accueil';
require 'views/partials/header.php';
?>

<section class="hero">
    <div class="hero-content">
        <span class="hero-badge">Plateforme de formation en ligne</span>
        <h1 class="hero-title">Apprenez.<br>Évoluez.<br><em>Réussissez.</em></h1>
        <p class="hero-sub">
            Découvrez nos formations professionnelles conçues par des experts.
            Inscription simple, paiement sécurisé, accès immédiat à vos cours.
        </p>
        <div class="hero-actions">
            <a href="index.php?page=formations" class="btn btn-primary">Voir les formations →</a>
            <a href="index.php?page=inscription" class="btn btn-outline">S'inscrire maintenant</a>
        </div>
    </div>
    <div class="hero-visual">
        <div class="visual-card vc1">
            <span class="vc-icon">💻</span>
            <span>Full-Stack Web</span>
        </div>
        <div class="visual-card vc2">
            <span class="vc-icon">🤖</span>
            <span>IA & Machine Learning</span>
        </div>
        <div class="visual-card vc3">
            <span class="vc-icon">🔐</span>
            <span>Cybersécurité</span>
        </div>
        <div class="visual-card vc4">
            <span class="vc-icon">☁️</span>
            <span>DevOps & Cloud</span>
        </div>
    </div>
</section>

<section class="stats-bar">
    <div class="stat-item">
        <strong>4</strong>
        <span>Formations</span>
    </div>
    <div class="stat-item">
        <strong>100%</strong>
        <span>En ligne</span>
    </div>
    <div class="stat-item">
        <strong>PHP MVC</strong>
        <span>Architecture</span>
    </div>
    <div class="stat-item">
        <strong>PDO</strong>
        <span>Base de données</span>
    </div>
</section>

<?php require 'views/partials/footer.php'; ?>
