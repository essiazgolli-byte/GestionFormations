<?php
// views/formations.php — Liste des formations
$pageTitle = 'Nos Formations';
require 'views/partials/header.php';
?>

<section class="page-section">
    <div class="page-header">
        <h1>Nos Formations</h1>
        <p>Choisissez la formation qui correspond à votre projet professionnel.</p>
    </div>

    <?php if (empty($formations)): ?>
        <div class="alert alert-info">Aucune formation disponible pour le moment.</div>
    <?php else: ?>
    <div class="formations-grid">
        <?php
        $niveaux_classes = [
            'Débutant'      => 'badge-green',
            'Intermédiaire' => 'badge-orange',
            'Avancé'        => 'badge-red',
        ];
        $icones = ['💻', '🤖', '🔐', '☁️'];
        $i = 0;
        foreach ($formations as $f):
            $badge_class = $niveaux_classes[$f['niveau']] ?? 'badge-green';
        ?>
        <article class="formation-card">
            <div class="fc-icon"><?= $icones[$i % 4] ?></div>
            <div class="fc-body">
                <span class="badge <?= $badge_class ?>"><?= htmlspecialchars($f['niveau']) ?></span>
                <h2><?= htmlspecialchars($f['titre']) ?></h2>
                <p><?= htmlspecialchars($f['description']) ?></p>
                <div class="fc-meta">
                    <span>⏱ <?= htmlspecialchars($f['duree']) ?></span>
                    <span class="fc-prix"><?= number_format($f['prix'], 2, ',', ' ') ?> DT</span>
                </div>
            </div>
            <div class="fc-footer">
                <a href="index.php?page=inscription&formation_id=<?= $f['id'] ?>"
                   class="btn btn-primary btn-sm">S'inscrire →</a>
            </div>
        </article>
        <?php $i++; endforeach; ?>
    </div>
    <?php endif; ?>
</section>

<?php require 'views/partials/footer.php'; ?>
