</main>

<footer class="site-footer">
    <div class="footer-inner">
        <div class="footer-brand">
            <span class="logo-icon">⬡</span>
            <span>EduPlatform</span>
        </div>
        <p class="footer-copy">
            TP6 — Architecture MVC &nbsp;|&nbsp; ISET'COM L2-GTIC &nbsp;|&nbsp;
            Dr. Asma Ayari &nbsp;|&nbsp; 2025–2026
        </p>
    </div>
</footer>

</body>
</html>
