<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'GestionFormations') ?> — EduPlatform</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body>

<header class="site-header">
    <nav class="navbar">
        <a href="index.php" class="logo">
            <span class="logo-icon">⬡</span>
            <span class="logo-text">EduPlatform</span>
        </a>
        <ul class="nav-links">
            <li><a href="index.php" class="nav-link <?= (($_GET['page'] ?? 'home') === 'home') ? 'active' : '' ?>">Accueil</a></li>
            <li><a href="index.php?page=formations" class="nav-link <?= (($_GET['page'] ?? '') === 'formations') ? 'active' : '' ?>">Formations</a></li>
            <li><a href="index.php?page=inscription" class="nav-link <?= (($_GET['page'] ?? '') === 'inscription') ? 'active' : '' ?>">S'inscrire</a></li>
            <?php if (isset($_SESSION['paiement_ok']) && $_SESSION['paiement_ok']): ?>
            <li><a href="index.php?page=cours" class="nav-link btn-cours <?= (($_GET['page'] ?? '') === 'cours') ? 'active' : '' ?>">Mes Cours 🎓</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>

<main class="main-content">
