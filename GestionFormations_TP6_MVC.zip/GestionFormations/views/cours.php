<?php
// views/cours.php — Accès aux cours (page protégée par session)
$pageTitle = 'Mes Cours';
require 'views/partials/header.php';
?>

<section class="page-section cours-page">
    <div class="page-header">
        <span class="hero-badge">🎓 Espace apprenant</span>
        <h1>Bienvenue, <?= htmlspecialchars($etudiant_prenom) ?> !</h1>
        <p>Formation : <strong><?= htmlspecialchars($formation_titre) ?></strong></p>
    </div>

    <div class="cours-grid">
        <?php foreach ($chapitres as $ch): ?>
        <div class="cours-card">
            <div class="cours-num">Chapitre <?= $ch['numero'] ?></div>
            <div class="cours-icon"><?= $ch['icone'] ?></div>
            <h2><?= htmlspecialchars($ch['titre']) ?></h2>
            <div class="cours-meta">
                <span>⏱ <?= htmlspecialchars($ch['duree']) ?></span>
            </div>
            <div class="cours-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?= ($ch['numero'] === 1) ? '100%' : (($ch['numero'] === 2) ? '45%' : '0%') ?>"></div>
                </div>
                <span class="progress-label">
                    <?php if ($ch['numero'] === 1): ?>
                        Terminé ✔
                    <?php elseif ($ch['numero'] === 2): ?>
                        En cours…
                    <?php else: ?>
                        À venir
                    <?php endif; ?>
                </span>
            </div>
            <a href="#" class="btn btn-sm <?= ($ch['numero'] <= 2) ? 'btn-primary' : 'btn-outline' ?>">
                <?= ($ch['numero'] === 1) ? 'Revoir' : (($ch['numero'] === 2) ? 'Continuer →' : 'Déverrouiller') ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="cours-notice">
        <p>🔒 Cette page est protégée par session PHP. Elle n'est accessible qu'après validation du paiement.</p>
    </div>
</section>

<?php require 'views/partials/footer.php'; ?>
