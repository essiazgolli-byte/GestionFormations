<?php
// views/succes.php — Page de confirmation après paiement
$pageTitle = 'Paiement confirmé';
require 'views/partials/header.php';
?>

<section class="page-section succes-page">
    <div class="succes-card">
        <div class="succes-icon">✅</div>
        <h1>Paiement confirmé !</h1>
        <p class="succes-msg">
            Félicitations <strong><?= htmlspecialchars($_SESSION['etudiant_prenom'] ?? '') ?></strong> !
            Votre inscription à la formation
            <strong>« <?= htmlspecialchars($_SESSION['formation_titre'] ?? '') ?> »</strong>
            a bien été enregistrée et votre paiement est validé.
        </p>
        <div class="succes-details">
            <div class="detail-item">
                <span class="detail-icon">📧</span>
                <span>Un email de confirmation vous sera envoyé</span>
            </div>
            <div class="detail-item">
                <span class="detail-icon">📚</span>
                <span>Vos cours sont maintenant accessibles</span>
            </div>
            <div class="detail-item">
                <span class="detail-icon">🆔</span>
                <span>N° inscription : <code>#<?= htmlspecialchars($_GET['id'] ?? '') ?></code></span>
            </div>
        </div>
        <a href="index.php?page=cours" class="btn btn-primary">
            Accéder à mes cours →
        </a>
    </div>
</section>

<?php require 'views/partials/footer.php'; ?>
