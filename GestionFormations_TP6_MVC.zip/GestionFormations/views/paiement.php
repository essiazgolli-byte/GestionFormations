<?php
// views/paiement.php — Page de paiement fictif
$pageTitle = 'Paiement';
require 'views/partials/header.php';
?>

<section class="page-section form-page">
    <div class="page-header">
        <h1>Simulation de Paiement</h1>
        <p>Cette page simule un terminal de paiement. Choisissez le résultat souhaité.</p>
    </div>

    <!-- Résumé de la commande -->
    <div class="recap-card">
        <h2>📋 Récapitulatif de la commande</h2>
        <table class="recap-table">
            <tr>
                <th>Étudiant</th>
                <td><?= htmlspecialchars($inscription['prenom'] . ' ' . $inscription['nom']) ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?= htmlspecialchars($inscription['email']) ?></td>
            </tr>
            <tr>
                <th>Formation</th>
                <td><?= htmlspecialchars($inscription['formation_titre']) ?></td>
            </tr>
            <tr>
                <th>Montant à payer</th>
                <td class="prix-highlight"><?= number_format($inscription['prix'], 2, ',', ' ') ?> DT</td>
            </tr>
        </table>
    </div>

    <!-- Message d'erreur de paiement -->
    <?php if ($erreur_paiement): ?>
    <div class="alert alert-error">
        ❌ <strong>Paiement refusé.</strong> Veuillez réessayer ou choisir un autre mode.
    </div>
    <?php endif; ?>

    <!-- Formulaire de simulation -->
    <div class="paiement-simulateur">
        <h2>💳 Terminal de paiement (simulation)</h2>
        <p class="simulateur-hint">
            Dans un vrai système, vous saisiriez vos coordonnées bancaires ici.
            Pour ce TP, simulez le résultat en cliquant sur un bouton ci-dessous.
        </p>

        <!-- Carte fictive (visuelle uniquement) -->
        <div class="fake-card">
            <div class="fake-card-chip">▬▬</div>
            <div class="fake-card-number">•••• •••• •••• 4242</div>
            <div class="fake-card-row">
                <span>TITULAIRE : <?= strtoupper(htmlspecialchars($inscription['prenom'] . ' ' . $inscription['nom'])) ?></span>
                <span>EXP: 12/28</span>
            </div>
        </div>

        <!-- Boutons de simulation -->
        <div class="paiement-buttons">
            <form method="POST" action="index.php?page=paiement&id=<?= $inscription['id'] ?>">
                <input type="hidden" name="mode" value="ok">
                <button type="submit" class="btn btn-success btn-full">
                    ✅ Simuler un paiement RÉUSSI
                </button>
            </form>
            <form method="POST" action="index.php?page=paiement&id=<?= $inscription['id'] ?>">
                <input type="hidden" name="mode" value="echec">
                <button type="submit" class="btn btn-danger btn-full">
                    ❌ Simuler un paiement REFUSÉ
                </button>
            </form>
        </div>
    </div>
</section>

<?php require 'views/partials/footer.php'; ?>
