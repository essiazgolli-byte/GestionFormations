<?php
// ============================================================
// models/Formation.php — Requêtes SQL sur la table formations
// TP6 - Architecture MVC - ISET'COM L2-GTIC
// ============================================================

require_once __DIR__ . '/Database.php';

class Formation {

    // Récupérer toutes les formations de la BD
    public static function getAll(): array {
        $pdo  = Database::connect();
        $stmt = $pdo->query('SELECT * FROM formations ORDER BY id');
        return $stmt->fetchAll();
    }

    // Récupérer une formation par son ID
    public static function getById(int $id): array|false {
        $pdo  = Database::connect();
        $stmt = $pdo->prepare('SELECT * FROM formations WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}
?>
